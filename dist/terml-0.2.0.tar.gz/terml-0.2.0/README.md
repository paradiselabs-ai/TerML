# TerML - AI-powered Terminal Assistant

TerML is an AI-powered terminal assistant that helps users understand and use terminal commands more effectively. It integrates with the Anthropic Claude AI model to provide explanations, suggestions, and assistance with various terminal tasks.

## Features

- Explain terminal outputs
- Suggest helpful commands based on history
- Interactive chat mode for in-depth assistance
- Debug command execution issues
- Automated command execution with user approval

## Installation

To install TerML, make sure you have Python 3.7+ installed, then run:

```shell
pip install terml
```

## Usage

After installation, you can start TerML by running:

```shell
terml
```

Use the following commands within TerML:

- `terml explain`: Explain the last command output
- `terml suggest`: Get a suggestion for the next command
- `terml chat -q`: Start a quick chat session with TerML
- `terml debug`: Debug the last command execution
- `terml auto --with-user`: Automatically run commands with user approval

## Configuration

TerML requires an Anthropic API key to function. Set your API key as an environment variable:

```shell
export ANTHROPIC_API_KEY='your-api-key-here'
```

## License

This project is licensed under the MIT License. See the LICENSE file for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## Support

If you encounter any problems or have any questions, please open an issue on the GitHub repository.
  